// os_dep/: the only layer that talks to Linux APIs (USB, cfg80211, netdev).
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/usb.h>
#include "drv_types.h"

static const struct usb_device_id mydrv_ids[] = {
	{ USB_DEVICE(MYDRV_VID, MYDRV_PID) },
	{ }
};
MODULE_DEVICE_TABLE(usb, mydrv_ids);

static int mydrv_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
	struct mydrv_priv *priv;
	int ret;

	priv = kzalloc(sizeof(*priv), GFP_KERNEL);
	if (!priv)
		return -ENOMEM;

	priv->udev = usb_get_dev(interface_to_usbdev(intf));
	usb_set_intfdata(intf, priv);

	ret = mydrv_core_init(priv);
	if (ret)
		goto err_put;
	ret = mydrv_hal_init(priv);
	if (ret)
		goto err_core;
	return 0;

err_core:
	mydrv_core_deinit(priv);
err_put:
	usb_set_intfdata(intf, NULL);
	usb_put_dev(priv->udev);
	kfree(priv);
	return ret;
}

static void mydrv_disconnect(struct usb_interface *intf)
{
	struct mydrv_priv *priv = usb_get_intfdata(intf);

	mydrv_hal_deinit(priv);
	mydrv_core_deinit(priv);
	usb_set_intfdata(intf, NULL);
	usb_put_dev(priv->udev);
	kfree(priv);
}

static struct usb_driver mydrv_driver = {
	.name       = "mydrv",
	.id_table   = mydrv_ids,
	.probe      = mydrv_probe,
	.disconnect = mydrv_disconnect,
};
module_usb_driver(mydrv_driver);

MODULE_DESCRIPTION("mydrv skeleton USB WiFi driver");
MODULE_LICENSE("GPL");
