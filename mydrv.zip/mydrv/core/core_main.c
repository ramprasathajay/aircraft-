// core/: chip-independent logic (mlme, tx/rx queues, security) goes here.
#include <linux/module.h>
#include "drv_types.h"

int mydrv_core_init(struct mydrv_priv *priv)
{
	dev_info(&priv->udev->dev, "core init\n");
	return 0;
}

void mydrv_core_deinit(struct mydrv_priv *priv)
{
	dev_info(&priv->udev->dev, "core deinit\n");
}
