# mydrv

Skeleton out-of-tree Linux USB driver, laid out like the Realtek vendor drivers.

| Folder      | Role |
|-------------|------|
| core/       | chip-independent logic |
| hal/        | chip-specific hardware code |
| os_dep/     | Linux glue (USB, cfg80211, netdev) |
| include/    | shared headers |
| platform/   | platform-specific tweaks |

## Build
    sudo apt install build-essential linux-headers-$(uname -r)
    make && make install
    sudo modprobe mydrv

Set `MYDRV_VID`/`MYDRV_PID` in `include/drv_types.h` first (see `lsusb`).

## DKMS
    sudo cp -r . /usr/src/mydrv-0.1.0
    sudo dkms install mydrv/0.1.0
