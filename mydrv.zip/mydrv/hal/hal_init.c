// hal/: chip-specific code (registers, firmware load, power on/off) goes here.
#include <linux/module.h>
#include "drv_types.h"

int mydrv_hal_init(struct mydrv_priv *priv)
{
	dev_info(&priv->udev->dev, "hal init\n");
	return 0;
}

void mydrv_hal_deinit(struct mydrv_priv *priv)
{
	dev_info(&priv->udev->dev, "hal deinit\n");
}
