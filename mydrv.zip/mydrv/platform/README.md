Per-platform tweaks (Android, ARM boards, etc.). Empty until needed.
