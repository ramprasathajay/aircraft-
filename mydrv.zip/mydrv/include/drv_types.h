#ifndef MYDRV_TYPES_H
#define MYDRV_TYPES_H
#include <linux/usb.h>

/* TODO: replace with your adapter's real USB IDs (check `lsusb`) */
#define MYDRV_VID 0x0000
#define MYDRV_PID 0x0000

struct mydrv_priv {
	struct usb_device *udev;
	int debug_level;
};

/* core/ */
int  mydrv_core_init(struct mydrv_priv *priv);
void mydrv_core_deinit(struct mydrv_priv *priv);
/* hal/ */
int  mydrv_hal_init(struct mydrv_priv *priv);
void mydrv_hal_deinit(struct mydrv_priv *priv);
#endif
